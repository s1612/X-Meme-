package com.crio.starter.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.crio.starter.data.Meme;
import com.crio.starter.service.MemeService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/memes")
@RequiredArgsConstructor
public class MemeController {

    private final MemeService memeService;
    @PostMapping
    public Map<String, String> createMeme(@RequestBody Meme meme) {
        Meme saved = memeService.addMeme(meme);
        return Map.of("id", saved.getId());
    }

    
    @GetMapping
    public List<Meme> getAllMemes() {
        return memeService.getAllMemes();
    }


    @GetMapping("/{id}")
    public ResponseEntity<Meme> getMemeById(@PathVariable String id) {
        return memeService.getMemeById(id)
                          .map(ResponseEntity::ok)
                          .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/test")
public String test() {
    return "MemeController is working!";
}
}





