package com.crio.starter.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.crio.starter.data.Meme;
import com.crio.starter.repository.MemeRepository;

@Service
@RequiredArgsConstructor
public class MemeService {

  private final MemeRepository memeRepository;

  public Meme addMeme(Meme meme) {
    if (meme.getName() == null || meme.getName().isBlank()
        || meme.getUrl() == null || meme.getUrl().isBlank()
        || meme.getCaption() == null || meme.getCaption().isBlank()) {
      throw new ResponseStatusException(HttpStatus.BAD_REQUEST, 
          "Name, URL and Caption are required");
    }

    memeRepository.findByNameAndUrlAndCaption(
        meme.getName(), meme.getUrl(), meme.getCaption())
        .ifPresent(existing -> {
          throw new ResponseStatusException(HttpStatus.CONFLICT, "Duplicate meme");
        });

    meme.setCreatedAt(LocalDateTime.now());
    return memeRepository.save(meme);
  }

  public List<Meme> getAllMemes() {
    return memeRepository.findTop100ByOrderByCreatedAtDesc();
  }

  public Optional<Meme> getMemeById(String id) {
    return memeRepository.findById(id);
  }
}
