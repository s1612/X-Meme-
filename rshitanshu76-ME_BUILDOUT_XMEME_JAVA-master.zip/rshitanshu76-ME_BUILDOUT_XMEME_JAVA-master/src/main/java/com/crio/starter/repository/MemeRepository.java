package com.crio.starter.repository;

import java.util.List;
import java.util.Optional;
import com.crio.starter.data.Meme;
import org.springframework.data.mongodb.repository.MongoRepository;

// public interface GreetingsRepository extends MongoRepository<GreetingsEntity, String> {
//   GreetingsEntity findByExtId(String extId);

//   Optional<GreetingsEntity> findByNameAndUrlAndCaption(String name, String url, String caption);
// }

public interface MemeRepository extends MongoRepository<Meme, String> {
  Optional<Meme> findByNameAndUrlAndCaption(String name, String url, String caption);

  List<Meme> findTop100ByOrderByCreatedAtDesc();
}


